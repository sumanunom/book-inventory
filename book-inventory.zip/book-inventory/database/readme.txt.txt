This is an simple online web store was made by using php , mysql and bootstrap. 

the sql for database is put in folder sql. 
the database contains many tables. 

To change the localhost, username, password for connecting to database, change it only one time in 
www_project/functions/database_functions.php -> db_connect() . Simple and fast
The base is localhost , root , , www_project 

to connect the admin section, click the name Nghi Le Thanh at the bottom. 
the name and pass for log in is admin , admin. Just to make it simple. 

the 2 main things are not fully implemented is contact and process purchase. 
Due to having to work with some security and online payment, the process site is just a place holder. 

for futher questions, please let me know. my email: nghi.lethanh2@cou.fi