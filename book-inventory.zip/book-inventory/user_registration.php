<?php
	$title = "Administration section";
	require_once "./template/header.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>USER REGISTRATION</title>
<style>
	p{
		text-align: left;
	}
</style>
</head>
<body>

	<div class=" jumbotron text-center"> 
      <div class="container">
        <h2>USER REGISTRATION</h2>
        </div>
    </div> 

	<form class="form-horizontal" method="post" action="user_confirm.php">
		<div class="form-group">
			<label for="name" class="control-label col-md-4">Name</label>
			<div class="col-md-4">
				<input type="text" name="name" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label for="pass" class="control-label col-md-4">email</label>
			<div class="col-md-4">
				<input type="email" name="email" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label for="pass" class="control-label col-md-4">Pass</label>
			<div class="col-md-4">
				<input type="password" name="pass" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label for="pass" class="control-label col-md-4">Ph Num</label>
			<div class="col-md-4">
				<input type="Number" name="ph" class="form-control">
			</div>
		</div>
		<div class="col-lg-8 col-lg-offset-5">
		<input type="submit" name="submit" class="btn btn-primary">
	</form>
<div class="form-group" >
			
				<p>Already have an account? <a href="user_login.php">Sign in</a>.</p>
			
		</div>

</body>
</html>