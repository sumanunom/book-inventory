<?php 
   session_start();
	//require_once "./functions/admin.php";
	//$title = "Add Book Store";
	//require_once "./template/header1.php";
	//require_once "./functions/database_functions.php";
	//$conn = db_connect();
	//$result = getAll($conn);

	$servername = "localhost";
	$username="root";
	$password="";
	$dbname="book1";


$con = mysqli_connect($servername, $username,$password,$dbname);
$db=mysqli_select_db($con,$dbname);

	if(isset($_POST['submit'])){
		$name = $_POST ['name'];
		$pass = $_POST ['pass'];
	 
		if($name=='')  
    {  
        //javascript use for input checking  
        echo"<script>alert('Please enter the Username')</script>";  
exit();//this use if first is not work then other will not show  
    }  
  
    if($pass=='')  
    {  
        echo"<script>alert('Please enter the password')</script>";  
exit();  
    }   

		$q ="SELECT * FROM `user` WHERE name ='$name' and pass = '$pass'";
		
		$rw =mysqli_query($con,$q);
		$num = mysqli_num_rows($rw);
		if($num == 1){
                  $_SESSION['name'] = $name;

				header('Location:user.php');
		}
	else {
		echo "<script>alert('WRONG USERNAME OR PASSWORD !')</script>";
		?>
		<META HTTP-EQUIV="Refresh" CONTENT="0; URL=user_login.php">
		<?php

	}
}
 ?>