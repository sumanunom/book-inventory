<?php
	$servername = "localhost";
	$username="root";
	$password="";
	$dbname="book1";

try{
$conn = mysqli_connect($servername, $username,$password,$dbname);
//echo("successful in connection \n");
}catch(MySQLi_Sql_Exception $ex){
echo("error in connection\n");
}
if(isset($_POST['submit'])){
		$name = $_POST ['name'];
		$email = $_POST [ 'email'];
		$pass = $_POST [ 'pass'];
		$ph = $_POST [ 'ph'];


	
$register_query = "INSERT INTO `user`(`name`, `email`, `pass`, `ph`) VALUES ('$name','$email','$pass','$ph')";

	try{
			$register_result = mysqli_query($conn, $register_query);
			if($register_result){
				if(mysqli_affected_rows($conn)>0){
					echo "<script>alert(' USER REGISTRATION SUCCESSFULL !')</script>";
					
					?>
			<META HTTP-EQUIV="Refresh" CONTENT="0; URL=user_login.php">

<?php
				}else{
					echo("Error in registration");
					 }		
		
				}
		}catch(Exception $ex){
									echo("error".$ex->getMessage());
							}
						}
			 
?>