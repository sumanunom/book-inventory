<?php
	$title = "Administration section";
	require_once "./template/header3.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>ADD NEW STORE</title>
<style>
	p{
		text-align: left;
	}
</style>
</head>
<body>

	<div class=" jumbotron text-center"> 
      <div class="container">
        <h2>ADD NEW STORE</h2>
        </div>
    </div> 

	<form class="form-horizontal" method="post" action="store_confirm.php">
		<div class="form-group">
			<label for="name" class="control-label col-md-4">Store Name</label>
			<div class="col-md-4">
				<input type="text" name="store" class="form-control">
			</div>
		</div>
	<div class="col-lg-8 col-lg-offset-5">
	<input type="submit" name="submit" class="btn btn-primary">
	<br>
	</form>
	<br>
<div class="form-group" >
				<div class="col-lg-6 col-lg-offset-0">
				<div class="btn btn-default"><a href="book_store.php">Cancel</a>
		</div>

</body>
</html>