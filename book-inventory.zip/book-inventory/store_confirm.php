
<?php
	$servername = "localhost";
	$username="root";
	$password="";
	$dbname="book1";

try{
$conn = mysqli_connect($servername, $username,$password,$dbname);

}catch(MySQLi_Sql_Exception $ex){
echo("error in connection\n");
}
if(isset($_POST['submit'])){
		$publisher_name = $_POST ['store'];
		


	
$register_query = "INSERT INTO `publisher`(`publisher_name`) VALUES ('$publisher_name')";

	try{
			$register_result = mysqli_query($conn, $register_query);
			if($register_result){
				if(mysqli_affected_rows($conn)>0){
					echo "<script>alert(' STORE REGISTRATION SUCCESSFULL !')</script>";
					
					?>
			<META HTTP-EQUIV="Refresh" CONTENT="0; URL=book_store.php">

<?php
				}else{
					echo("Error in registration");
					 }		
		
				}
		}catch(Exception $ex){
									echo("error".$ex->getMessage());
							}
						}
			 
?>