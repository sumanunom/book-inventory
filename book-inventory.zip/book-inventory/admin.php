<?php
	$title = "Administration section";
	require_once "./template/header.php";
?>
    
 <div class=" jumbotron text-center"> 
      <div class="container">
        <h2>ADMIN LOGIN</h2>
        </div>
    </div> 



	<form class="form-horizontal" method="post" action="admin_verify.php">
		<div class="form-group">
			<label for="name" class="control-label col-md-4">Name</label>
			<div class="col-md-4">
				<input type="text" name="name" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label for="pass" class="control-label col-md-4">Pass</label>
			<div class="col-md-4">
				<input type="password" name="pass" class="form-control">
			</div>
		</div>
		<div class="col-lg-20 col-lg-offset-5">
		<input type="submit" name="submit" class="btn btn-primary">
	</form>

<div class=" text-left"> 
      <div class="container">
        <h4>Username : admin</h4>
        	<h4>password : 123</h4>
        
        </div>
    </div> 