<?php
	if(!isset($_SESSION['name']) && $_SESSION['name'] != true){
		header("Location: index.php");
	}
?>